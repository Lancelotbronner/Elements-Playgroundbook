/*:
# Elements

- Note: **The _original_**

Here is the original state of the game elements!

What I mean by "original" is that this has no UI, except for the Answers's template, which was made on my computer, and that the source code has been written entirely in Playgrounds, not even using GoodReader as I do with the others. I of course used GoodReader to create the playground book and worked on it a little, but it is an almost perfect copy of the one lying on one of my playground's pages.

You can check out the source code below, but do not copy, please, I worked for that stuff.

Have fun!

- Note:
The beautiful image on the playground isn't mine, I took it from [Joshua Vizzacco](https://dribbble.com/shots/675090-elements-icons) on [Dribbble](https://dribbble.com)
*/

show(/*#-editable-code*/""/*#-end-editable-code*/)

//MARK: ELEMENTS SETUP

import Foundation

class Game {
    
    //MARK: Options
    
    class Options {
        static var removeTries: Bool = false
        
        static var list = ["Hide tried combinations"]
    }
    
    //MARK: Save Handling
    
    static func save() {
        let ud = UserDefaults.standard
        ud.set(namedDiscovery, forKey: "Data")
        ud.set(namedOptions, forKey: "Option")
        ud.set(tried, forKey: "Tries")
        ud.set(forged, forKey: "Forged")
    }
    
    static func load() {
        let ud = UserDefaults.standard
        let dict = ud.dictionary(forKey: "Data") as? [String : Bool] ?? [:]
        let options = ud.dictionary(forKey: "Option") as? [String : Any] ?? [:]
        let tried = ud.array(forKey: "Tries") as? [String] ?? []
        let forged = ud.array(forKey: "Forged") as? [[String]] ?? []
        
        for item in elements {
            if dict[item.name] != nil {
                item.discovered = dict[item.name]!
            }
        }
        
        for item in options {
            switch item.key {
                case "HideTried": Options.removeTries = item as? Bool ?? false
            default: continue
            }
        }
        
        for item in tried {
            let separated = item.split(separator: "|")
            let pair = Element.Pair(first: String(separated[0] ?? ""), second: String(separated[1] ?? ""))
            Game.tried.append(pair)
        }
        
        self.forged = forged
    }
    
    static func reset() {
        let ud = UserDefaults.standard
        ud.removeObject(forKey: "Data")
        ud.removeObject(forKey: "Option")
        ud.removeObject(forKey: "Tries")
        ud.removeObject(forKey: "Forged")
    }
    
    //MARK: Element
    
    class Element: CustomStringConvertible {
        
        var name: String
        var from: [Pair]
        var forge: [[String]]
        var discovered: Bool = false
        
        var description: String {
            return name
        }
        
        struct Pair: CustomStringConvertible {
            var first: String
            var second: String
            var description: String {
                return "\(first) &amp; \(second)"
            }
        }
        
        convenience init(name: String, father: String? = nil, mother: String? = nil) {
            self.init()
            self.name = name
            
            if father != nil && mother != nil {
                let pair = Element.Pair(first: father!, second: mother!)
                self.from = [pair]
            } else {
                discovered = true
                self.from = []
            }
        }
        
        convenience init(name: String, forge: [[String]]) {
            self.init()
            self.name = name
            self.forge = forge
        }
        
        convenience init(name: String, from: [Pair]) {
            self.init()
            self.name = name
            self.from = from
        }
        
        init() {
            name = ""
            from = []
            forge = []
        }
        
        static func ==(element1: Element, element2: Element) -> Bool {
            return element1.name == element2.name && element1.discovered == element2.discovered
        }
        
        static func !=(element1: Element, element2: Element) -> Bool {
            return !(element1.name != element2.name) && !(element1.discovered != element2.discovered)
        }
}
    
    //MARK: Game
    
    static let actions = ["Combine", "Forge", "Show Progress", "Explain", "Hint", "Options", "Reset", "Quit"]
    
    static var elements: [Element] = []
    
    static var tried: [Element.Pair] = []
    static var forged: [[String]] = []
    
    static private var namedDiscovery : [String : Bool] {
        var dict = [String : Bool]()
        
        for item in elements {
            dict[item.name] = item.discovered
        }
        
        return dict
    }
    
    static private var tries: [String] {
        var strings = [String]()
        
        for item in Game.tried {
            strings.append("\(item.first)|\(item.second)")
        }
        
        return strings
    }
    
    static private var namedOptions: [String : Any] {
        var options = [String : Any]()
        options["HideTried"] = Options.removeTries
        return options
    }
    
    static func addElement(_ name: String, _ father: String? = nil, _ mother: String? = nil) {
        elements.append(Element(name: name, father: father, mother: mother))
    }
    
    static func addElement(_ name: String, _ from: [(father: String, mother: String)]) {
        var paired : [Element.Pair] = []
        
        for item in from {
            let pair = Element.Pair(first: item.father, second: item.mother)
            paired.append(pair)
        }
        
        elements.append(Element(name: name, from: paired))
    }
    
    static func addElement(_ name: String, _ from: [Element.Pair]) {
        elements.append(Element(name: name, from: from))
    }
    
    static func addElement(_ name: String, _ forge: [String]) {
        elements.append(Element(name: name, forge: [forge]))
    }
    
    static func addElement(_ name: String, _ forge: [[String]]) {
        elements.append(Element(name: name, forge: forge))
    }
    
    static var _discovered: [Element]? = nil
    static var discovered: [Element] {
        if _discovered == nil {
            let elems = Game.elements.filter({ $0.discovered })
            _discovered = elems
            return elems
        } else {
            return _discovered!
        }
    }

    static var _disNames: [String]? = nil
    static var disNames: [String] {
        if _disNames == nil {
            let ns = names(list: discovered)
            _disNames = ns
            return _disNames!
        } else {
            return _disNames!
        }
    }
    
    static func availableNames(first: String) -> [String] {
        var pool = disNames
        let already = tried.filter({ $0.first == first })
        
        var eliminate: [Int] = []
        
        for x in 0..<pool.count {
            let pooled = pool[x]
            
            for item in already {
            if item.second == pooled {
                eliminate.append(x)
            }
        }
        }
        
        for i in eliminate.reversed() {
            pool.remove(at: i)
        }
        
        return pool
    }
    
    static var unknown: [Element] {
        return Game.elements.filter({ !$0.discovered })
    }
    
    static func names(list: [Element]) -> [String] {
        var ns = [String]()
        
        for el in list {
            ns.append(el.name)
        }
        
        return ns
    }
    
    static func element(_ string: String) -> Element? {
        return elements.filter({ $0.name == string }).first
    }
    
    static func knownElement(_ string: String) -> Element? {
        return discovered.filter({ $0.name == string }).first
    }
    
    static func couldCombine(_ element: Element) -> (father: String?, mother: String?) {
            for pair in element.from {
                let father = knownElement(pair.first)
                let mother = knownElement(pair.second)
                if (father != nil && mother != nil) {
                    return (father?.name, mother?.name)
                }
            }
        
        return (nil, nil)
    }
    
    static func couldForge(_ element: Element) -> [String]? {
        for forge in element.forge {
            var use = true
            
            for name in forge {
                let elem = knownElement(name)
                if elem == nil {
                    use = false
                    break
                }
            }
            
            if use {
                return forge
            }
        }
        return nil
    }
    
    static func combine(_ first: Element, _ second: Element) -> [Element] {
        var result = unknown.filter({
            for pair in $0.from {
                if (pair.first == first.name && pair.second == second.name) || (pair.first == second.name && pair.second == first.name) {
                    return true
                }
            }
            
            return false
        })
        
        return result
    }
    
    static func forge(from: [Element]) -> [Element] {
        var result: [Element] = []
        var pool = unknown.filter({ $0.forge.count > 0 })
        pool = pool.filter({ $0.forge.filter({ $0.count == from.count }).count > 0 })
        
        for possibility in pool {
            for recipe in possibility.forge.filter({ $0.count == from.count }) {
                var use = true
                for x in 0..<from.count {
                    let fromed = from[x]
                    if !recipe.contains(fromed.name) {
                        use = false
                        break
                    }
                }
                
                if use {
                    result.append(possibility)
                }
            }
        }
        
        return result
    }
    
}

//MARK: GAME SET-UP

show("Welcome to the game of elements! Here you must combine two elements to make a new one or forge multiple elements in one! This game will save your progress, so no worries! If you need anything else, choose the \"Explain\" action in the menu.")
show("Loading...")

var play = true

    let file = Bundle.main.path(forResource: "Universe", ofType: "txt")
    let content = try? String(contentsOfFile: file!) ?? ""
    let text = content?.split(separator: "\n") ?? []
    
    for line in text {
        let items = line.split(separator: " ")
        
        switch String(items[0]) {
            case "default":
                Game.addElement(String(items[1]))
            continue
            
            case ":": break
            default: continue
        }
        
        let name = String(items[1])
        if String(items[2]) == "C" {
            var froms = items[3].split(separator: "/")
            
            var from: [Game.Element.Pair] = []
            for each in froms {
                let pair = each.split(separator: "&")
                from.append(Game.Element.Pair(first: String(pair[0]), second: String(pair[1])))
            }
            
            Game.addElement(name, from)
            continue
            
        } else if String(items[2]) == "F" {
            var froms = String(items[3]).split(separator: "/")
            
            var from: [[String]] = []
            for each in froms {
                let forge = each.split(separator: "&")
                var forging: [String] = []
                for each in forge {
                    forging.append(String(each))
                }
                
                from.append(forging)
            }
            
            Game.addElement(name, from)
            continue
        }
    }

//MARK: GAME LOADING

Game.load()

var change = UserDefaults.standard.dictionary(forKey: "Data") != nil

if change {
    show("Loaded last save.")
    
} else {
    if Game.unknown.count == 0 {
        show("There seems to be no elements to discover!")
        play = false
        
    } else  {
        show("You have to try and discover all \(Game.unknown.count) unknown elements!")
    }
}

//MARK: PLAYING METHODS

func dealWithResults(results: [Game.Element]) {
    for result in results {
        if result.discovered {
            show("You have rediscovered the \(result.name).")
            continue
        }
        
        result.discovered = true
        show("You have discovered \(result.name)! (\(Game.discovered.count + 1) / \(Game.elements.count))")
        Game._discovered?.append(result)
        Game._disNames?.append(result.name)
    }
    
    if results.isEmpty {
        show("You haven't discovered anything.")
    }
}

//MARK: PLAY

while play {
    show("What do you wish to do?")
    let action = askForChoice("Action", options: Game.actions)
    
    switch action {
        case "Combine":
            show("What will your first element be?")
            var first = Game.knownElement(askForChoice("Element", options: Game.disNames))!
    
            show("What will your second element be?")
    
            var list: [String] = []
            if !Game.Options.removeTries {
                list = Game.disNames
            } else {
                list = Game.availableNames(first: first.name)
            }
    
            while list.count == 0 {
                show("There are no more combinations with the first element you selected, let's try that again.")
                continue
            }
    
            let second = Game.knownElement(askForChoice("Element", options: list))!
            let pair = Game.Element.Pair(first: first.name, second: second.name)
    
            if Game.tried.contains(where: { tried in 
                return (tried.first == first.name && tried.second == second.name)
            }) {
                show("You have already tried this combination!")
                continue
        
            } else {
                Game.tried.append(pair)
                let inverse = Game.Element.Pair(first: pair.second, second: pair.first)
                Game.tried.append(inverse)
            }
    
            let results = Game.combine(first, second)
            dealWithResults(results: results)
        
        case "Quit":
            show("Save and Quitting")
            Game.save()
            play = false
        continue
        
        case "Show Progress":
            show("\(Game.discovered.count) / \(Game.elements.count) elements discovered.")
        
        case "Explain":
            show("You have to combine two of the right elements using the \"Combine\" action to discover a new one, and such until you discovered them all.")
        
        case "Options":
            show("Which option do you wish to view?")
            let option = askForChoice("Option", options: Game.Options.list)
        
        switch option {
            case "Hide tried combinations":
                show("This option hides the combinations you have already tried. (\(Game.Options.removeTries ? "Hide" : "Show"))")
                
        default: continue
        }
        
            let modify = askForChoice("Action", options: ["Edit", "Leave", "Reset"])
        
        switch modify {
            case "Edit":
                show("To which value do you want to set the option?")
                
                switch option {
                case "Hide tried combinations":
                    Game.Options.removeTries = (askForChoice("Value", options: ["Show", "Hide"]) == "Show" ? false : true)
                    show("Option set.")
                    
                default: continue
            }
            
            case "Reset":
            switch option {
                case "Hide tried combinations":
                Game.Options.removeTries = false
                show("Set option to Show.")
                
                default: continue
            }
            
            case "Leave": continue
            default: continue
        }
        
        case "Reset":
            show("Are you certain?")
            let answer = (askForChoice("Reset?", options: ["No", "Yes"]) == "Yes" ? true : false)
            
            if answer {
                show("Erased current game.")
                Game.reset()
                play = false
        }
        
        continue
        
        case "Hint":
            show("Do you really want to be given an element?")
            let answer = (askForChoice("Hint?", options: ["No", "Yes"]) == "Yes" ? true : false)
        
            if answer {
                var found = false
            
                loop: while !found {
                    for x in 0..<Game.unknown.count {
                        let elem = Game.unknown[x]
                        let result = Game.couldCombine(elem)
                        
                        if result.father != nil {
                            found = true
                            show("You could create \(elem.name) from \(result.father!) and \(result.mother!).")
                            break loop
                        }
                    }
                    
                    show("There does't seem to be any available.")
                    break
                }
            }
        
        case "Forge":
            show("How many elements would you like to forge? Choose a number between 3 and 8.")
            var number = 0
            number = askForNumber("Elements")
            
            while (number <= 3 || number >= 8) {
                show("That's not in between 3 and 8.")
                number = askForNumber("Elements")
        }
        
            var forging: [Game.Element] = []
            
            for x in 1...number {
                show("What will the #\(x) element be?")
                let elem = Game.knownElement(askForChoice(options: Game.disNames))
                forging.append(elem!)
            }
            
            if Game.forged.contains(where: { (array) in
                var same = true
                for each in forging {
                    if !array.contains(each.name) {
                        same = false
                    }
                }
                
                return same
                
            }) {
                show("You have already tried this combination!")
                continue
            }
            
            Game.forged.append(Game.names(list: forging))
            let results = Game.forge(from: forging)
            dealWithResults(results: results)
        
default:
    show("There has been an error, missing action case.")
        continue
}
    
    if Game.discovered.count == Game.elements.count {
        show("Congratulations! You have found all \(Game.elements.count) elements!")
        Game.reset()
        play = false
        continue
    }
}