//MARK: LIVE VIEW SETUP

setupLiveView()