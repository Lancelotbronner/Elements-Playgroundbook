import Foundation

extension Int {
    
    public var toFloat: Float {
        return Float(self)
    }
    
    public var toDouble: Double {
        return Double(self)
    }
    
    public var toString: String {
        return String(self)
    }
    
    public var squareRoot: Float {
        return self.toFloat.squareRoot()
    }
    
    public var toInt64: Int64 {
        return Int64(self)
    }
    
    public var toInt32: Int32 {
        return Int32(self)
    }
    
    public var toInt16: Int16 {
        return Int16(self)
    }
    
    public var toInt8: Int8 {
        return Int8(self)
    }
    
    public func split() -> [Int] {
        var array: [Int] = []
        let chars = self.toString
        for char in chars {
            if let int = char.toInt {
                array += int
            }
        }
        
        return array
    }
    
    public func multiple(of: Int) -> Bool {
        let divided = self.toFloat / of.toFloat
        let decimals = divided.decimalString("").toInt ?? -1
        return decimals == 0
    }
    
    public func primes() -> [Int] {
        var prime: [Int] = []
        for item in 2..<self {
            let divided = self.toDouble / item.toDouble
            let decimals = divided.decimal
            
            if decimals == 0 {
                prime += item
            }
        }
        
        return prime
    }
    
    var isPalindromic: Bool {
        let numbers = self.split()
        let reverse = numbers.reversed().toArray
        return numbers == reverse
    }
    
}

extension Int64 {
    
    public var toFloat: Float {
        return Float(self)
    }
    
    public var toDouble: Double {
        return Double(self)
    }
    
    public var toString: String {
        return String(self)
    }
    
    public var squareRoot: Float {
        return self.toFloat.squareRoot()
    }
    
    public var toInt: Int {
        return Int(self)
    }
    
    public var toInt32: Int32 {
        return Int32(self)
    }
    
    public var toInt16: Int16 {
        return Int16(self)
    }
    
    public var toInt8: Int8 {
        return Int8(self)
    }
    
    public func multiple(of: Int64) -> Bool {
        let divided = self.toFloat / of.toFloat
        let decimals = divided.decimalString("").toInt ?? -1
        return decimals == 0
    }
    
}

extension Int32 {
    
    public var toFloat: Float {
        return Float(self)
    }
    
    public var toDouble: Double {
        return Double(self)
    }
    
    public var toString: String {
        return String(self)
    }
    
    public var squareRoot: Float {
        return self.toFloat.squareRoot()
    }
    
    public var toInt: Int {
        return Int(self)
    }
    
    public var toInt64: Int64 {
        return Int64(self)
    }
    
    public var toInt16: Int16 {
        return Int16(self)
    }
    
    public var toInt8: Int8 {
        return Int8(self)
    }
    
    public func multiple(of: Int32) -> Bool {
        let divided = self.toFloat / of.toFloat
        let decimals = divided.decimalString("").toInt ?? -1
        return decimals == 0
    }
    
}

extension Int16 {
    
    public var toFloat: Float {
        return Float(self)
    }
    
    public var toDouble: Double {
        return Double(self)
    }
    
    public var toString: String {
        return String(self)
    }
    
    public var squareRoot: Float {
        return self.toFloat.squareRoot()
    }
    
    public var toInt: Int {
        return Int(self)
    }
    
    public var toInt64: Int64 {
        return Int64(self)
    }
    
    public var toInt32: Int32 {
        return Int32(self)
    }
    
    public var toInt8: Int8 {
        return Int8(self)
    }
    
    public func multiple(of: Int16) -> Bool {
        let divided = self.toFloat / of.toFloat
        let decimals = divided.decimalString("").toInt ?? -1
        return decimals == 0
    }
    
}

extension Int8 {
    
    public var toFloat: Float {
        return Float(self)
    }
    
    public var toDouble: Double {
        return Double(self)
    }
    
    public var toString: String {
        return String(self)
    }
    
    public var squareRoot: Float {
        return self.toFloat.squareRoot()
    }
    
    public var toInt: Int {
        return Int(self)
    }
    
    public var toInt64: Int64 {
        return Int64(self)
    }
    
    public var toInt32: Int32 {
        return Int32(self)
    }
    
    public var toInt16: Int16 {
        return Int16(self)
    }
    
    public func multiple(of: Int8) -> Bool {
        let divided = self.toFloat / of.toFloat
        let decimals = divided.decimalString("").toInt ?? -1
        return decimals == 0
    }
    
}

extension Float {
    
    public var toDouble: Double {
        return Double(self)
    }
    
    public var toString: String {
        return String(self)
    }
    
    public var squareRoot: Float {
        return self.squareRoot()
    }
    
    public var toInt: Int {
        return Int(self)
    }
    
    public var toInt64: Int64 {
        return Int64(self)
    }
    
    public var toInt32: Int32 {
        return Int32(self)
    }
    
    public var toInt16: Int16 {
        return Int16(self)
    }
    
    public var decimal: Int {
        return self.toString.split(separator: ".")[1].toInt ?? 0
    }
    
    public var decimals: [Int] {
        return decimal.split()
    }
    
    public func decimalString(_ separator: String) -> String {
        return decimals.toString(separator)
    }
    
    public func multiple(of: Float) -> Bool {
        let divided = self / of
        let decimals = divided.decimalString("").toInt ?? -1
        return decimals == 0
    }
    
}

extension Double {
    
    public var toFloat: Float {
        return Float(self)
    }
    
    public var toString: String {
        return String(self)
    }
    
    public var squareRoot: Int {
        return self.toFloat.squareRoot().toInt
    }
    
    public var toInt: Int {
        return Int(self)
    }
    
    public var toInt64: Int64 {
        return Int64(self)
    }
    
    public var toInt32: Int32 {
        return Int32(self)
    }
    
    public var toInt16: Int16 {
        return Int16(self)
    }
    
    public var toInt8: Int8 {
        return Int8(self)
    }
    
    public var decimal: Int {
        let string = self.toString
        let split = string.split(separator: ".")
        if !string.contains(".") {
            return -1
        }
        
        let decimals = split[1]
        let integer = decimals.toInt
        return integer ?? 0
    }
    
    public var decimals: [Int] {
        return decimal.split()
    }
    
    public func decimalString(_ separator: String) -> String {
        return decimals.toString(separator)
    }
    
    public func multiple(of: Double) -> Bool {
        let divided = self.toFloat / of.toFloat
        let decimals = divided.decimalString("").toInt ?? -1
        return decimals == 0
    }
    
}

extension Substring {
    
    public var toString: String {
        return String(self)
    }
    
    public var toInt: Int? {
        return self.toString.toInt
    }
    
}

extension String {
    
    public var toFloat: Float? {
        return Float(self)
    }
    
    public var toDouble: Double? {
        return Double(self)
    }
    
    public var toInt: Int? {
        return Int(self)
    }
    
    public var toInt64: Int64? {
        return Int64(self)
    }
    
    public var toInt32: Int32? {
        return Int32(self)
    }
    
    public var toInt16: Int16? {
        return Int16(self)
    }
    
    public var toInt8: Int8? {
        return Int8(self)
    }
    
    public static func /(string: String, character: Character) -> [Substring] {
        return string.split(separator: character)
    }
    
    public static func /(string: String, character: String) -> [Substring] {
        return string.split(separator: character.first ?? " ")
    }
    
}

extension Character {
    
    public var toFloat: Float? {
        return Float(self.toString)
    }
    
    public var toDouble: Double? {
        return Double(self.toString)
    }
    
    public var toString: String {
        return String(self)
    }
    
    public var toInt: Int? {
        return Int(self.toString)
    }
    
    public var toInt64: Int64? {
        return Int64(self.toString)
    }
    
    public var toInt32: Int32? {
        return Int32(self.toString)
    }
    
    public var toInt16: Int16? {
        return Int16(self.toString)
    }
    
    public var toInt8: Int8? {
        return Int8(self.toString)
    }
    
}

extension Array {
    
    public static func +=(array: inout [Element], item: Element) {
        array.append(item)
    }
    
}

extension Array where Element: SignedInteger {
    
    public func toString(_ separator: String) -> String {
        var string = ""
        for item in self {
            string += item.toString
            string += separator
        }
        
        return string
    }
    
    public func biggest() -> Int {
        var biggest = -1
        for item in self {
            if item > biggest {
                biggest = item.toInt
            }
        }
        
        return biggest
    }
    
    public func smallest() -> Int {
        var smallest = -1
        for item in self {
            if item < smallest {
                smallest = item.toInt
            }
        }
        
        return smallest
    }
    
}

extension Array where Element: StringProtocol {
    
    public func toStrings() -> [String] {
        var array: [String] = []
        for element in self {
            array += String(element)
        }
        
        return array
    }
    
}

extension ReversedRandomAccessCollection {
    
    var toArray: [Element] {
        var temp: [Element] = []
        for item in self {
            temp += item
        }
        
        return temp
    }
    
}

extension SignedInteger {
    
    public var toFloat: Float {
        return Float(self.toInt)
    }
    
    public var toDouble: Double {
        return Double(self.toInt)
    }
    
    public var toString: String {
        return String(self.toInt)
    }
    
    public var squareRoot: Int {
        return self.toFloat.squareRoot().toInt
    }
    
    public var toInt: Int {
        return Int(self)
    }
    
    public var toInt64: Int64 {
        return Int64(self)
    }
    
    public var toInt32: Int32 {
        return Int32(self)
    }
    
    public var toInt16: Int16 {
        return Int16(self)
    }
    
    public var toInt8: Int8 {
        return Int8(self)
    }
    
}
